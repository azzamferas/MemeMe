//
//  ViewController.swift
//  MemeMe
//
//  Created by Feras Azzam on 1/25/19.
//  Copyright © 2019 Syriail. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate
{
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var bottomText: UITextField!
    @IBOutlet weak var topText: UITextField!
    @IBOutlet weak var imagePickerView: UIImageView!
    @IBOutlet weak var bottomToolbar: UIToolbar!
    @IBOutlet weak var topToolbar: UIToolbar!
    enum PickPhotoType: Int { case camera = 0, gallery }
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // setup top and bottom text fields attributes.
        self.topText.delegate = self
        self.topText.text = "TOP"
        topText.defaultTextAttributes = memeTextAttributes
        topText.textAlignment = NSTextAlignment.center
        self.bottomText.delegate = self
        self.bottomText.text = "Bottom"
        bottomText.defaultTextAttributes = memeTextAttributes
        bottomText.textAlignment = NSTextAlignment.center
        shareButton.isEnabled = false
        
        
    }
    // setup the attributes to be used by the text fields.
    let memeTextAttributes: [NSAttributedString.Key: Any] = [
        NSAttributedString.Key.strokeColor: UIColor.black,
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key.strokeWidth:  -3.0
    ]
    // clear the view to have a new meme.
    func clearMeme()
    {
        topText.text = "TOP"
        bottomText.text = "bottom"
        imagePickerView.image = nil
        shareButton.isEnabled = false
    }
    // cancel button action.
    @IBAction func cancelMeme(_ sender: Any) {
        
        clearMeme()
        
    }
    
    // code to be implemented when the view will appear (subscribe to the keyboard notifications)
    override func viewWillAppear(_ animated: Bool) {
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    // code to be implemented when the view will disappear. (Unsubscribe to the keyboard notifications)
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    // add observers to notification of keyboard will show or hide.
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
          NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
   // remove the observers.
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    // code to be implemented when the keyboard will show (shift the view)
    @objc func keyboardWillShow(_ notification:Notification) {
        
        view.frame.origin.y -= getKeyboardHeight(notification)  
    
    }
    
    // code to be implemented when the keyboard will hide (return the view to its original position)
    @objc func keyboardWillHide(_ notification:Notification) {
        
        view.frame.origin.y = 0
    }
    
    // get the keyboard height.
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
        
        
        
    }
   // show the UIViewController that matches the source type
    func pickImageFromSource (source: UIImagePickerController.SourceType)
    {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = source
        present(imagePicker, animated: true, completion: nil)
    }
    // code to be implemented according to the tag of the button (start the image picker from camera or from photo library)
    @IBAction func pickAnimage(_ sender: UIButton)
    {
        switch(PickPhotoType(rawValue: sender.tag)!) {
        case .camera:
            pickImageFromSource(source: .camera)
        case .gallery:
           pickImageFromSource(source: .photoLibrary)
        }
    }
    
    // outlet for the camera button
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
   
   // get the image that have been chosen in the image picker.
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imagePickerView.image = image
            //imagePickerView.contentMode = .scaleAspectFill
        }
        dismiss(animated: true, completion: nil)
        shareButton.isEnabled = true
    }
// code to be implemented when the user cancel the image picker controller.
   func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    // code to be implemented when the user start editing the text. (clear the label)
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.text = ""
    }
    // code to be implemented when the user press ther return button on the keyboard. (hide the keyboard)
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true;
    }
    
    
    
    // code to be implemented when pressing on the share button (start activity view controller to share or save the meme image)
    @IBAction func shareAction(_ sender: Any) {
        let memedImage = generateMemedImage()
        
        let activityControler = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        present(activityControler, animated: true, completion: nil)
        if activityControler.completionWithItemsHandler != nil
        {
            save(image: memedImage)
            dismiss(animated: true, completion: nil)
        }
        
    
    
    }
    // save the meme
    func save(image: UIImage) {
        // Create the meme
        
       
        _ = Meme(topText: topText.text!, bottomText: bottomText.text!, originalImage: imagePickerView.image!, memedImage: image)
    }
   // combine the texts and image into one image.
    func generateMemedImage() -> UIImage {
        
        // TODO: Hide toolbar and navbar
        
        bottomToolbar.isHidden = true
        topToolbar.isHidden = true
        self.navigationController?.isNavigationBarHidden = true
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        // TODO: Show toolbar and navbar
        topToolbar.isHidden = false
        bottomToolbar.isHidden = false
        self.navigationController?.isNavigationBarHidden = false
        return memedImage
    }
}

// meme struct.
struct Meme
{
    let topText: String
    let bottomText: String
    let originalImage: UIImage
    let memedImage: UIImage
    
}
